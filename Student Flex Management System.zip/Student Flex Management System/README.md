
                                                           "Project Title: Flex Management System"

-> Description:
              This One is My Semester Project With 3 Modoules.
              1)Admin
              2)Teacher
              3)Student
-> Features:
-OOP Concepts: Utilized OOP principles for this project Completion.
-File Handling: Used File Handling to Handle Complex Code Structure.
-Console Interface: Designed a user-friendly console interface for Better interaction.

Caution:
         Trying to Complete This Project, Now Some Functionalties Are Not Working.
         Sorry For it.
         Regards By: Fida Kainth
